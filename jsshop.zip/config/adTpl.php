<?php
/**
 * Created by PhpStorm.
 * Date: 2018/4/10 0010
 * Time: 15:47
 */

return [
    'list' => [
        '广告位模板1' => 'tpl1_slider'

    ]
];