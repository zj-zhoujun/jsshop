<?php
/**
 *
 *  广告位模板配置
 *
 */

return [
    'list' => [
        '广告位模板1' => 'tpl1_slider'

    ]
];