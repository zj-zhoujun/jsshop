<?php

namespace app\common\model;

class WeiXinOfficialToken extends Common
{

    protected $name = 'weixin_official_token';


}
