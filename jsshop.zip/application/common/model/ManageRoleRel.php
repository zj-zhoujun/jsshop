<?php
/**
 * 平台角色和平台管理员关联关系表,没啥实际的业务，业务写在了manage模型里
 */

namespace app\common\model;

class ManageRoleRel extends Common
{

}