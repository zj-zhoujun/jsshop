<?php
namespace app\common\model;

class BillAftersalesImages extends Common
{

}
