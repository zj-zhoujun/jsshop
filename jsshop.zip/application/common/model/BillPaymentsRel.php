<?php
namespace app\common\model;



class BillPaymentsRel extends Common
{

}