<?php
namespace app\common\model;

class BillReshipItems extends Common
{

}
