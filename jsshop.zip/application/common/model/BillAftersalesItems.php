<?php
namespace app\common\model;

class BillAftersalesItems extends Common
{

}
