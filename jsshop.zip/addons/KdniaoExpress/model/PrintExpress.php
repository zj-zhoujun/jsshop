<?php
/**
 * 快递单打印模型
 */
namespace addons\KdniaoExpress\model;
use think\Model;
class PrintExpress extends Model
{
    protected $autoWriteTimestamp = true;
    protected $createTime = 'ctime';
    protected $updateTime = 'utime';


}
